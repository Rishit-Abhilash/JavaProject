import java.util.Scanner;
import weathernews.WeatherNews;
import WWD.WeeklyWeatherData;
import WWD.WeeklyWeatherData.*;

//First Class
class CityWeather {
    private String city;
    private float temperature;
    private float humidity;
    private String conditions;

    public CityWeather(String city, int temperature, int humidity, String conditions) {
        this.city = city;
        this.temperature = temperature;
        this.humidity = humidity;
        this.conditions = conditions;
    }
    public void displayWeeklyForecast() {
        System.out.println("Weekly Weather Forecast for " + city);
        // Implement the logic to display the weekly forecast here
        // You can fetch data from a weather API and display it
        System.out.println("Implement the logic to display the weekly forecast here.");
    }
    public void WeeklyWeatherData() {
        System.out.println("City: " + city);
        System.out.println("Temperature: " + temperature + "°C");
        System.out.println("Humidity: " + humidity + "%");
        System.out.println("Conditions: " + conditions);
    }
}

// interface Quiz {
//     void start();
// }

// class WeatherQuiz implements Quiz {
//     @Override
//     public static void startQuiz() {
//         // Sample quiz questions
//         String[] questions = {
//                 "What is the capital of France?",
//                 "Which planet is known as the Red Planet?",
//                 "What is the freezing point of water in Celsius?"
//         };

//         // Sample answers corresponding to the quiz questions
//         String[] answers = {"Paris", "Mars", "0"};

//         // Display quiz questions and get user answers
//         Scanner scanner = new Scanner(System.in);
//         int score = 0;

//         for (int i = 0; i < questions.length; i++) {
//             System.out.println("Question " + (i + 1) + ": " + questions[i]);
//             System.out.print("Your Answer: ");
//             String userAnswer = scanner.nextLine();

//             // Check user's answer
//             if (userAnswer.equalsIgnoreCase(answers[i])) {
//                 System.out.println("Correct!");
//                 score++;
//             } else {
//                 System.out.println("Incorrect. The correct answer is: " + answers[i]);
//             }
//         }

//         // Display quiz result
//         System.out.println("Quiz Complete. Your Score: " + score + "/" + questions.length);
//     }
// }

class WeatherService {
    public static void startTravelPlanner() {
        // Sample implementation - suggest travel destinations based on weather preferences
        System.out.println("Enter your preferred weather conditions (e.g., sunny, rainy, snowy): ");
        Scanner scanner = new Scanner(System.in);
        String weatherPreference = scanner.nextLine();

        // Display suggestions without database connectivity
        System.out.println("Travel Suggestions:");
        if (weatherPreference.equalsIgnoreCase("sunny")) {
            System.out.println("- Beach destinations");
        } else if (weatherPreference.equalsIgnoreCase("rainy")) {
            System.out.println("- Explore cities with cozy cafes");
        } else if (weatherPreference.equalsIgnoreCase("snowy")) {
            System.out.println("- Visit snowy mountain resorts");
        } else {
            System.out.println("- No suggestions for the given weather preference");
        }
    }
}

// //Second CLass
class WeatherQuiz {
    public static void startQuiz() {
        // Sample quiz questions
        String[] questions = {
                "What is the capital of France?",
                "Which planet is known as the Red Planet?",
                "What is the freezing point of water in Celsius?"
        };

        String[] answers = {"Paris", "Mars", "0"};

        // Display quiz questions and get user answers
        Scanner scanner = new Scanner(System.in);
        int score = 0;

        for (int i = 0; i < questions.length; i++) {
            System.out.println("Question " + (i + 1) + ": " + questions[i]);
            System.out.print("Your Answer: ");
            String userAnswer = scanner.nextLine();

            // Check user's answer
            if (userAnswer.equalsIgnoreCase(answers[i])) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Incorrect. The correct answer is: " + answers[i]);
            }
        }

        // Display quiz result
        System.out.println("Quiz Complete. Your Score: " + score + "/" + questions.length);
    }
}



public class WeatherApp {
        private static WeatherRecord[] historicalWeatherData = {
                new WeatherRecord("2023-01-01", "Rainy", 20),
                new WeatherRecord("2023-02-14", "Sunny", 25),
                new WeatherRecord("2023-07-04", "Clear", 30)
        };

        public static WeeklyWeatherData getCityWeatherData(String city) {

        if (city.equalsIgnoreCase("Mumbai")) 
        {
             return new MumbaiWeather();
        }
        if (city.equalsIgnoreCase("Delhi")) 
        {
            return new DelhiWeather();
        } 
        else if (city.equalsIgnoreCase("Bengaluru")) 
        {
            return new BengaluruWeather();
        } 
        else if (city.equalsIgnoreCase("Chennai")) 
        {
            return new ChennaiWeather();
        }
        else if (city.equalsIgnoreCase("Kolkata")) 
        {
            return new KolkataWeather();
        } 
        else if (city.equalsIgnoreCase("Hyderabad")) 
        {
            return new HyderabadWeather();
        } 
        else if (city.equalsIgnoreCase("Pune")) {
            return new PuneWeather();
        } 
        else if (city.equalsIgnoreCase("Jaipur")) {
            return new JaipurWeather();
        } 
        else if (city.equalsIgnoreCase("Ahmedabad")) {
            return new AhmedabadWeather();
        } 
        else if (city.equalsIgnoreCase("Lucknow")) {
            return new LucknowWeather();
        }
        else 
        {
            // Handle the case where the city is not recognized
            System.out.println("City not found in the database.");
            return null;
        } 
        }
    


    
    public static void main (String[]args){
            Scanner scanner = new Scanner(System.in);
            String[] cities = {"Mumbai", "Delhi", "Bengaluru", "Chennai", "Kolkata", "Hyderabad", "Pune", "Jaipur", "Ahmedabad", "Lucknow"};
            int[] temperatures = {25, 30, 28, 34, 31, 33, 29, 36, 30, 29};
            int[] humidities = {72, 45, 70, 55, 75, 50, 65, 40, 55, 70};
            String[] conditions = {"Sunny ☀ ", "Thunderstorm ⛈ ", "Rainy 🌧 ", "Hail 🌧 ", "Cloudy ☁ ", "Sunny ☀ ", "Snow ❄ ", "Sunny ☀ ", "Rainy 🌧 ", "Thunderstorm ⛈ "};

            while (true) {
                System.out.println("Weather App Menu:");
                System.out.println("1. Select a city");
                System.out.println("2. Weather quiz");
                System.out.println("3. Virtual travel planner");
                System.out.println("4. Weather time machine");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                if (choice == 1) {
                    System.out.println("Select a city:");
                    for (int i = 0; i < cities.length; i++) {
                        System.out.println((i + 1) + ". " + cities[i]);
                    }
                    System.out.print("Enter the city number: ");
                    int cityNumber = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    if (cityNumber >= 1 && cityNumber <= cities.length) {
                        int index = cityNumber - 1;
                        System.out.println("City: " + cities[index]);
                        System.out.println("Temperature: " + temperatures[index] + "°C");
                        System.out.println("Humidity: " + humidities[index] + "%");
                        System.out.println("Conditions: " + conditions[index]);

                        // Ask if the user wants the weekly forecast
                        System.out.print("Do you want to know the weekly weather prediction for " + cities[index] + " (yes/no)? ");
                        String weeklyForecastChoice = scanner.nextLine().toLowerCase();

                        if (weeklyForecastChoice.equals("yes")) {
                            WeeklyWeatherData cityWeatherData = getCityWeatherData(cities[index]);
                            if (cityWeatherData != null) {
                                System.out.println("Weekly Weather Details for " + cities[index] + ":");
                                for (int day = 0; day < 7; day++) {
                                    System.out.println("Day " + (day + 1) + ":");
                                    System.out.println("Temperature: " + cityWeatherData.getTemperatures()[day] + "°C");
                                    System.out.println("Humidity: " + cityWeatherData.getHumidities()[day] + "%");
                                    System.out.println("Condition: " + cityWeatherData.getConditions()[day]);
                                    System.out.println();
                                }
                            } else {
                                System.out.println("City weather data not found.");
                            }
                        } else {
                            System.out.println("Weekly forecast not requested.");
                        }
                    }
                    }
                    else if (choice == 2) {
                        WeatherQuiz.startQuiz();
                    }
                    else if (choice == 3){
                        WeatherService.startTravelPlanner();
                    }
                    else if (choice == 4){
                        exploreHistoricalWeather();
                    }
                    else if (choice == 5) {
                        System.out.print("Do you want to view weather news (yes/no)? ");
                        String newsChoice = scanner.nextLine().toLowerCase();
    
    
                        if (newsChoice.equals("yes")) {
                            WeatherNews weatherNews = new WeatherNews();
                            weatherNews.fetchWeatherNews();
                        }
                        System.out.println();
                        System.out.println("Exiting the Weather App. Goodbye!");
                        break;


                        // System.out.println("Exiting the Weather App. Goodbye!");
                        // break;
                    } 
                    
                    else {
                        System.out.println("Invalid choice. Please enter 1 or 2.");
                    }
                }
        
}
}
private static void exploreHistoricalWeather(){
        // Get user input for the date
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the date (YYYY-MM-DD) to explore historical weather:");
        String date = scanner.nextLine();

        // Check if historical weather data is available for the entered date
        WeatherRecord weatherRecord = findWeatherRecord(date);
        if (weatherRecord != null) {
            System.out.println("Historical Weather Data for " + date + ":");
            System.out.println(weatherRecord);
        } else {
            System.out.println("No historical weather data available for the entered date.");
        }
    }

    private static WeatherRecord findWeatherRecord(String date) {
        for (WeatherRecord record : historicalWeatherData) {
            if (record.getDate().equals(date)) {
                return record;
            }
        }
        return null; // Date not found
    }


class WeatherRecord {
    private String date;
    private String condition;
    private int temperature;

    public WeatherRecord(String date, String condition, int temperature) {
        this.date = date;
        this.condition = condition;
        this.temperature = temperature;
    }

    public String getDate() {
        return date;
    }

    @Override
    public String toString() {
        return "Condition: " + condition + ", Temperature: " + temperature + "°C";
    }
}
            




