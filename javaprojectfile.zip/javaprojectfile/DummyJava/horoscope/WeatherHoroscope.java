// File: WeatherHoroscope.java

package horoscope;

public interface WeatherHoroscope {
    String generateHoroscope();
}
