
public interface jokes {

}
