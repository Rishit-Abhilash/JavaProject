ityNumber <= cities.length) {
                        int index = cityNum