package jokes;

public class jokesinterface {

    String tellJoke();
}

