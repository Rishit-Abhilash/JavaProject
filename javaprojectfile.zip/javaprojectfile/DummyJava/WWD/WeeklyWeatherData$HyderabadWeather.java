    package WWD;

public class WeeklyWeatherData$HyderabadWeather extends WeeklyWeatherData {
   public WeeklyWeatherData$HyderabadWeather() {
      super(new int[]{33, 34, 35, 32, 30, 31, 33}, new int[]{65, 70, 68, 72, 75, 71, 68}, new String[]{"Sunny ☀", "Partly Cloudy \ud83c\udf24", "Sunny ☀", "Rainy \ud83c\udf27", "Cloudy ☁", "Sunny ☀", "Partly Cloudy \ud83c\udf24"});
   }
}
  